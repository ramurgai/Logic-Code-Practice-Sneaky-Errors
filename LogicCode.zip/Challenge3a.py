name = input("What is your name?: ")
def greeting(name):
    print(f"Hello {name}, how are you doing?")

greeting(name)