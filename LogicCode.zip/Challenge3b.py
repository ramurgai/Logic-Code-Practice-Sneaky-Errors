num = int(input("Enter a number: "))

def evenOrOdd(num):
    if num % 2 == 0:
        print("That number is even")
    else:
        print("That number is odd")

evenOrOdd(num)