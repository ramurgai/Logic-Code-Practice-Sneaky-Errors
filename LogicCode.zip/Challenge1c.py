num = int(input("Enter a number: "))

if num > 0:
    print("That is a positive number")
elif num < 0:
    print("That is a negative number")
else:
    print("That is the number zero")
