fruit = ["apple","orange","pineapple","lemon","plum","advocado","tomato","banana","strawberry","blueberry"]

for i in fruit:
    print(i)