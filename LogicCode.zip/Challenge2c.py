num = int(input("Enter a number: "))
x = num
while x > 1:
    x -=1
    num *= x
print(num)