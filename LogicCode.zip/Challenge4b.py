studentDict = {"Marcus": "A", "Biruk": "A", "Rahul": "A", "Quint": "A"}

for key, value in studentDict.items():
    print(f"Student Name: {key}, Grade: {value}")