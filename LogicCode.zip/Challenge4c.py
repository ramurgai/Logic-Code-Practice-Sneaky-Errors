lst = [12, 22, 32, 42, 52, 62, 72, 82, 92, 10]
x = 0
for i in lst:
    if i > x:
        x = i

print(x)